from PIL import Image

def encrypt_image(input_path, output_path, key):
    img = Image.open(input_path)
    pixels = img.load()

    for i in range(img.size[0]):
        for j in range(img.size[1]):
            r, g, b = pixels[i, j]
            pixels[i, j] = ((r + key) % 256,
                            (g + key) % 256,
                            (b + key) % 256)

    img.save(output_path)
    print("Encrypted image saved as", output_path)

def decrypt_image(input_path, output_path, key):
    img = Image.open(input_path)
    pixels = img.load()

    for i in range(img.size[0]):
        for j in range(img.size[1]):
            r, g, b = pixels[i, j]
            pixels[i, j] = ((r - key) % 256,
                            (g - key) % 256,
                            (b - key) % 256)

    img.save(output_path)
    print("Decrypted image saved as", output_path)

if __name__ == "__main__":
    choice = input("Encrypt or Decrypt (e/d): ").lower()
    input_path = input("Enter image path: ")
    output_path = input("Enter output path: ")
    key = int(input("Enter key: "))

    if choice == 'e':
        encrypt_image(input_path, output_path, key)
    else:
        decrypt_image(input_path, output_path, key)
